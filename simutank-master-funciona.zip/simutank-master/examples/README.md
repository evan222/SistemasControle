Example of PID controller using the simulator. Run simutank.py first!  
Try to change the type of controller and the configuration.  

### USAGE - Set Point = 15 cm:
```
$ python controller_pid.py 15 
```  

![](https://raw.githubusercontent.com/augustomatheuss/simutank/master/plot/octavePlot.png)  
