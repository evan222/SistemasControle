**Octave Example**  

![](https://raw.githubusercontent.com/augustomatheuss/simutank/master/plot/octavePlot.png)

