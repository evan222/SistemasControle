##Simutank graphical user interface.  

GUI only for Unix-like systems for now.  

#Compilation:  

gcc gsimutank.c -o gsimutank -lpthread -lGL -lGLU -lglut

Run simutank.py first!  

![](https://github.com/augustomatheuss/simutank/blob/master/gui/gui.png)
