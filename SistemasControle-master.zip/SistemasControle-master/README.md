# SistemasControle

## For this you will need: Python 2.7, Kivy, Kivy Garden module and Garden Graph module for Kivy. 
